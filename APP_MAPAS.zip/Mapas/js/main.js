// Importamos las clases necesarias desde otros archivos
import Mapa from './Mapa.js';
import Excel from './Excel.js';
import Atraccio from './Atraccio.js';
import Museu from './Museu.js';
import PuntInteres from './PuntInteres.js';

// Creamos un array vacío para guardar los puntos de interés
let punts = [];

// Creamos una instancia del mapa
const mapa = new Mapa();

// Obtenemos las referencias a los elementos HTML del DOM
const fileInput = document.getElementById("fileInput");
const tipusSelect = document.getElementById("tipus");
const ordenarSelect = document.getElementById("ordenacio");
const filtrarInput = document.getElementById("filtrarNom");
const llista = document.getElementById("llista");
const totalElem = document.getElementById("total");
const banderaDiv = document.getElementById("bandera");
const ciutatDiv = document.getElementById("ciutat");

// Añadimos un evento cuando se cambia el archivo cargado
fileInput.addEventListener("change", async (event) => {
  // Obtenemos el primer archivo cargado
  const file = event.target.files[0];

  // Comprobamos si el archivo termina en .csv
  if (!file.name.endsWith(".csv")) {
    alert("El fitxer no és csv");
    return; // Salimos si no es un CSV
  }

  // Leemos el contenido del archivo usando el módulo Excel
  const data = await Excel.readCSV(file);

  // Vaciamos la lista de puntos anterior
  punts = [];

  // Borramos los puntos del mapa actual
  mapa.borrarPunt();

  // Creamos un Set para guardar tipos únicos de puntos
  const tipusSet = new Set();

  // Recorremos cada fila del archivo CSV
  data.forEach((row, index) => {
    // Mostramos la fila leída por consola
    console.log("Fila leída:", row);

    // Si no hay al menos 13 columnas, ignoramos la fila
    if (row.length < 13) {
      console.warn(`Fila ${index} ignorada: no tiene suficientes columnas.`);
      return;
    }

    // Extraemos cada valor de la fila
    const [id, pais, ciutat, nom, direccio, tipus, lat, long, puntuacio, horaris, preu, moneda, descripcio] = row;

    // Convertimos latitud y longitud a número
    const latNum = parseFloat(lat);
    const longNum = parseFloat(long);

    // Si la latitud o longitud no son válidas, ignoramos la fila
    if (isNaN(latNum) || isNaN(longNum)) {
      console.warn(`Fila ${index} ignorada por lat/long inválidos:`, lat, long);
      return;
    }

    let punto;

    // Creamos una instancia de Atraccio si el tipo es "Atraccio"
    if (tipus === "Atraccio") {
      punto = new Atraccio(id, pais, ciutat, nom, direccio, tipus, latNum, longNum, puntuacio, horaris, parseFloat(preu), moneda);
    }
    // Creamos una instancia de Museu si el tipo es "Museu"
    else if (tipus === "Museu") {
      punto = new Museu(id, pais, ciutat, nom, direccio, tipus, latNum, longNum, puntuacio, horaris, parseFloat(preu), moneda, descripcio);
    }
    // Si no es ninguno de los anteriores, creamos una instancia genérica
    else {
      punto = new PuntInteres(id, pais, ciutat, nom, direccio, tipus, latNum, longNum, puntuacio);
    }

    // Añadimos el punto al array de puntos
    punts.push(punto);

    // Añadimos el tipo al set para luego crear los filtros
    tipusSet.add(tipus);
  });

  // Mostramos la lista de puntos en el panel
  mostrarLlista();

  // Rellenamos el desplegable con los tipos únicos
  cargarFiltros(tipusSet);

  // Actualizamos el número total de puntos
  totalElem.innerText = `Total: ${punts.length}`;

  // Mostramos los puntos en el mapa
  mostrarPuntsMapa();

  // Si hay puntos cargados, mostramos la información del país
  if (punts.length > 0) {
    // Obtenemos info como la bandera y ciudad del país
    const info = await Excel.getInfoCountry(punts[0].pais);

    // Mostramos la bandera del país
    banderaDiv.innerHTML = `<img src="${info.flag}" alt="bandera" />`;

    // Mostramos la ciudad principal del país
    ciutatDiv.innerText = info.city;

    // Movemos el mapa a la posición inicial del país
    mapa.actualitzarPosInitMapa(info.lat, info.lon);
  }
});

// Función que muestra la lista de puntos filtrada y ordenada
function mostrarLlista() {
  // Obtenemos el tipo de punto seleccionado en minúsculas
  const tipus = tipusSelect.value.toLowerCase();

  // Obtenemos el texto que se está escribiendo para filtrar por nombre
  const nomFilter = filtrarInput.value.toLowerCase();

  // Filtramos los puntos por tipo (o todos si se ha seleccionado "Tots")
  let llistaFiltrada = punts.filter(p => {
    return (tipus === "tots" || p.tipus.toLowerCase() === tipus);
  });

  // Ordenamos por nombre, ascendente o descendente
  if (ordenarSelect.value === "asc") {
    llistaFiltrada.sort((a, b) => a.nom.localeCompare(b.nom));
  } else {
    llistaFiltrada.sort((a, b) => b.nom.localeCompare(a.nom));
  }

  // Limpiamos la lista HTML
  llista.innerHTML = "";

  // Recorremos los puntos filtrados
  llistaFiltrada.forEach(p => {
    // Creamos un div por cada punto
    const div = document.createElement("div");
    div.classList.add("element");

    // Si el punto es un museo, mostramos información detallada
    if (p instanceof Museu) {
      div.classList.add("museu");
      div.innerHTML = `<strong>${p.nom}</strong> (${p.ciutat})<br>
        Tipo: ${p.tipus}<br>
        Horarios: ${p.horaris}<br>
        Precio: ${p.preuIva}<br>
        Descripción: ${p.mostrarDescripcion()}`;
    }
    // Si es una atracción, mostramos otra info
    else if (p instanceof Atraccio) {
      div.classList.add("atraccio");
      div.innerHTML = `<strong>${p.nom}</strong> (${p.ciutat})<br>
        Tipo: ${p.tipus}<br>
        Horarios: ${p.horaris}<br>
        Precio: ${p.preuIva}`;
    }
    // Si es otro tipo, solo mostramos lo básico
    else {
      div.classList.add("espai");
      div.innerHTML = `<strong>${p.nom}</strong> (${p.ciutat})<br>
        Tipo: ${p.tipus}`;
    }

    // Creamos el botón para eliminar el punto
    const btnEliminar = document.createElement("button");
    btnEliminar.textContent = "Eliminar";

    // Añadimos el evento de eliminar al botón
    btnEliminar.addEventListener("click", () => {
      // Confirmamos si el usuario realmente quiere eliminarlo
      if (confirm("Estàs segur que vols eliminar el punt d'interès?")) {
        // Quitamos el punto de la lista
        punts = punts.filter(el => el.id !== p.id);

        // Actualizamos la lista, el mapa y el total
        mostrarLlista();
        mostrarPuntsMapa();
        totalElem.innerText = `Total: ${punts.length}`;
      }
    });

    // Añadimos el botón al div del punto
    div.appendChild(btnEliminar);

    // Añadimos el div al contenedor de la lista
    llista.appendChild(div);
  });
}

// Función para cargar los filtros de tipo en el desplegable
function cargarFiltros(tipusSet) {
  // Limpiamos el select actual
  tipusSelect.innerHTML = "";

  // Creamos la opción "Tots" (todos)
  const opTots = document.createElement("option");
  opTots.value = "Tots";
  opTots.textContent = "Tots";
  tipusSelect.appendChild(opTots);

  // Añadimos una opción por cada tipo encontrado
  tipusSet.forEach(t => {
    const op = document.createElement("option");
    op.value = t;
    op.textContent = t;
    tipusSelect.appendChild(op);
  });
}

// Función para mostrar los puntos en el mapa (filtrados)
function mostrarPuntsMapa() {
  // Borramos los puntos anteriores del mapa
  mapa.borrarPunt();

  // Obtenemos el tipo y nombre a filtrar
  const tipus = tipusSelect.value.toLowerCase();
  const nomFilter = filtrarInput.value.toLowerCase();

  // Recorremos todos los puntos
  punts.forEach(p => {
    // Mostramos por consola lo que se va a pintar
    console.log("Filtrando punto:", p.nom, p.latitud, p.longitud);

    // Mostramos en el mapa si cumple los filtros
    if ((tipus === "tots" || p.tipus.toLowerCase() === tipus) && p.nom.toLowerCase().includes(nomFilter)) {
      mapa.mostrarPunt(p.latitud, p.longitud, p.mostrarInfo());
    }
  });
}
// Evento: al escribir en el filtro de nombre
filtrarInput.addEventListener("input", () => {
  mostrarLlista();       // Actualizamos la lista
  mostrarPuntsMapa();    // Actualizamos el mapa
});

// Evento: al cambiar el orden alfabético
ordenarSelect.addEventListener("change", () => mostrarLlista());

// Evento: al cambiar el tipo de punto
tipusSelect.addEventListener("change", () => {
  mostrarLlista();       // Actualizamos la lista
  mostrarPuntsMapa();    // Actualizamos el mapa
});