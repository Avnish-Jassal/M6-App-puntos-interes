import PuntInteres from './PuntInteres.js';

class Museu extends PuntInteres {
    constructor(id, pais, ciutat, nom, direccio, tipus, latitud, longitud, puntuacio, horaris, preu, moneda, descripcio) {
        super(id, pais, ciutat, nom, direccio, tipus, latitud, longitud, puntuacio);
        this.horaris = horaris;
        this.preu = preu;
        this.moneda = moneda;
        this.descripcio = descripcio;
    }

    get preuIva() {
        const IVA = 1.21;
        if (this.preu === 0) return "Entrada gratuïta";
        return `${(this.preu * IVA).toFixed(2)}${this.moneda} (IVA)`;
    }

    mostrarDescripcion() {
        return this.descripcio ? this.descripcio : "Sin descripción disponible";
    }
}

export default Museu;
