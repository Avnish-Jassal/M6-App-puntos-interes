import PuntInteres from './PuntInteres.js';

// Classe Atraccio que hereta de PuntInteres
class Atraccio extends PuntInteres {
    constructor(id, pais, ciutat, nom, direccio, tipus, latitud, longitud, puntuacio, horaris, preu, moneda) {
        super(id, pais, ciutat, nom, direccio, tipus, latitud, longitud, puntuacio);
        this.horaris = horaris;
        this.preu = preu;
        this.moneda = moneda;
    }

    // Retorna el preu amb IVA o gratis si es 0
    get preuIva() {
        const IVA = 1.21;
        if (this.preu === 0) return "Entrada gratuïta";
        return `${(this.preu * IVA).toFixed(2)}${this.moneda} (IVA)`;
    }
}

export default Atraccio;