class Mapa {
    constructor() {
        this.inicializarMapa();
    }

    // Crea el mapa i mostra la posició inicial per defecte (Barcelona)
    inicializarMapa() {
        this.mapa = L.map('mapa').setView([41.3851, 2.1734], 11); // Barcelona

        // Afegeix els tiles d'OpenStreetMap
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(this.mapa);

        // Punt inicial fix de "Estàs aquí"
        this.marker = L.marker([41.40241, 2.19439]).addTo(this.mapa);
        this.marker.bindPopup("<b>Estàs aquí</b>").openPopup();
    }

    // Actualitza la posició inicial del mapa a unes coordenades noves
    actualitzarPosInitMapa(lat, lon) {
        this.mapa.setView([lat, lon], 11);
    }

    // Mostra un punt al mapa amb una descripció (popup)
    mostrarPunt(lat, lon, descripcio = "") {
        L.marker([lat, lon]).addTo(this.mapa).bindPopup(descripcio);
    }

    // Elimina tots els punts del mapa (excepte el tile base)
    borrarPunt() {
        this.mapa.eachLayer(layer => {
            if (layer instanceof L.Marker && layer !== this.marker) {
                this.mapa.removeLayer(layer);
            }
        });
        // També eliminem el punt inicial si existeix
        if (this.marker) {
            this.mapa.removeLayer(this.marker);
            this.marker = null;
        }
    }

    // Retorna la posició actual de l'usuari com una Promise (lat, lon)
    getPosicioActual() {
        return new Promise((resolve, reject) => {
            if (!navigator.geolocation) {
                reject("El navegador no suporta la geolocalització");
            } else {
                navigator.geolocation.getCurrentPosition(
                    (position) => {
                        resolve({
                            lat: position.coords.latitude,
                            lon: position.coords.longitude
                        });
                    },
                    (error) => reject(error)
                );
            }
        });
    }
}

export default Mapa;