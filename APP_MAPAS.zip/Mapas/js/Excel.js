class Excel {
    // Método para leer un archivo CSV
    // Devuelve una lista de arrays, cada uno representando una fila del CSV
    static async readCSV(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader(); // Creamos un lector de archivos
            reader.onload = (event) => {
                // Dividimos el contenido por líneas y luego por punto y coma (;)
                const lines = event.target.result.split("\n").map(line => line.split(";"));
                resolve(lines); // Devolvemos el resultado
            };
            reader.readAsText(file); // Leemos el archivo como texto
        });
    }

    // Método para obtener información de un país usando la API REST Countries
    // Recibe el código del país (ej: "ES") y devuelve un objeto con ciudad, bandera, lat y lon
    static async getInfoCountry(code) {
        try {
            // Llamamos a la API con el código del país
            const response = await fetch(`https://restcountries.com/v3.1/alpha/${code}`);
            const data = await response.json(); // Convertimos la respuesta a JSON
            const pais = data[0]; // La información viene en un array

            // Devolvemos un objeto con la info necesaria
            return {
                city: pais.name.common,
                flag: pais.flags.svg,
                lat: pais.capitalInfo.latlng[0],
                lon: pais.capitalInfo.latlng[1]
            };
        } catch (error) {
            // Si hay error, lo mostramos y devolvemos datos por defecto
            console.error("Error al consultar la API del país:", error);
            return {
                city: "Desconocido",
                flag: "",
                lat: 0,
                lon: 0
            };
        }
    }
}
export default Excel;