// Classe base per a tots els punts d'interès
class PuntInteres {
    constructor(id, pais, ciutat, nom, direccio, tipus, latitud, longitud, puntuacio) {
        this.id = id;
        this.pais = pais;
        this.ciutat = ciutat;
        this.nom = nom;
        this.direccio = direccio;
        this.tipus = tipus;
        this.latitud = parseFloat(latitud);
        this.longitud = parseFloat(longitud);
        this.puntuacio = puntuacio;
    }

    // Mostra informació bàsica del punt
    mostrarInfo() {
        return `<strong>${this.nom}</strong><br>${this.direccio}<br>${this.ciutat}`;
    }
}

export default PuntInteres;
